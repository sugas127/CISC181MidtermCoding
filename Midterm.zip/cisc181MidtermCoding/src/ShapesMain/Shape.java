package ShapesMain;

abstract class Shape {
	public Shape() {	
	}
	public abstract double area();
	public abstract double perimeter();
}





